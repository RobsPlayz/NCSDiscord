﻿namespace Discord
{
    public enum PermissionTarget
    {
        Role,
        User
    }
}
