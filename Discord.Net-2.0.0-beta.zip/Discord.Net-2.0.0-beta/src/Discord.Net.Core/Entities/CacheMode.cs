﻿namespace Discord
{
    public enum CacheMode
    {
        AllowDownload,
        CacheOnly
    }
}
