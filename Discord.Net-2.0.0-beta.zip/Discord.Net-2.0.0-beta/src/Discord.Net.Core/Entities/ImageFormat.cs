﻿namespace Discord
{
    public enum ImageFormat
    {
        Auto,
        WebP,
        Png,
        Jpeg,
        Gif,
    }
}
