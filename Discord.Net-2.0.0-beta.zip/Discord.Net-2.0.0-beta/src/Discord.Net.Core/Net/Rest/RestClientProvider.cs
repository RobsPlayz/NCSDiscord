﻿namespace Discord.Net.Rest
{
    public delegate IRestClient RestClientProvider(string baseUrl);
}
