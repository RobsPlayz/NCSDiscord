﻿namespace Discord.Net.Udp
{
    public delegate IUdpSocket UdpSocketProvider();
}
