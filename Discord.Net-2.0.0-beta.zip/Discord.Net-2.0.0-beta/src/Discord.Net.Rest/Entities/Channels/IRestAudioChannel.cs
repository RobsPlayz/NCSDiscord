﻿namespace Discord.Rest
{
    public interface IRestAudioChannel : IAudioChannel
    {
    }
}
