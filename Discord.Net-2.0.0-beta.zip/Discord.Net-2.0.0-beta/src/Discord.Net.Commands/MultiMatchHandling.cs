﻿namespace Discord.Commands
{
    public enum MultiMatchHandling
    {
        Exception,
        Best
    }
}
