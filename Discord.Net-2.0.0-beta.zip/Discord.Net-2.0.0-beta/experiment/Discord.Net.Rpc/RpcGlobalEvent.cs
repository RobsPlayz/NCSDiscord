﻿namespace Discord.Rpc
{
    public enum RpcGlobalEvent
    {
        ChannelCreated,
        GuildCreated,
        VoiceSettingsUpdated
    }
}
