﻿namespace Discord.Rpc
{
    public interface IRpcPrivateChannel
    {
    }
}
